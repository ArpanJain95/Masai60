export default function Navbar() {
  return (
    <div className="navbar">
      <h3>Navbar</h3>
    </div>
  );
}
